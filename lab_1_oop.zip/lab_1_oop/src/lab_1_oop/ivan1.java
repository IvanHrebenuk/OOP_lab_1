package lab_1_oop;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ivan1 {

	public static void main(String[] args) {
		JFrame frame=new JFrame("First"); 
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		frame.setSize(400,250);
		    frame.setVisible(true);
		final JTextField textField=new JTextField(20);
		final JTextArea textArea=new JTextArea(10,30);
		 JButton btn=new JButton("Zamina");
		 
		 
		 frame.getContentPane().add(btn,BorderLayout.EAST);
			frame.getContentPane().add(textField,BorderLayout.NORTH);
			frame.getContentPane().add(textArea,BorderLayout.SOUTH);
			
		    btn.addActionListener(new ActionListener() {
		        
		        public void actionPerformed(ActionEvent e){
		  		  String lol = new String();
		  		   lol = textField.getText();

		  		 int count_small = 0;
		  		int count_tall = 0;
		  		char [] lolch = lol.toCharArray ();
		  		int count_symbol = 0;
		  		int count_space = 0;
		  		for (char element : lol.toCharArray()){
		  		    count_symbol++;
		  		    if(element == ' '){count_space++;}
		  		}
	//	 System.out.println(count_space);
		  		
		  		String[] sq = new String[count_symbol];
		  		for(int i=0;i<count_symbol;i++){
		  			String sub2 = new String(lol.substring(i,i+1)); 

			  		if(sub2 == sub2.toUpperCase()){ count_tall++;}
			  		else count_small++;
		  		  
		  		}
		  		count_tall = count_tall - count_space;
		  		int csns = count_symbol - count_space;
	textArea.setText("����� �������� = "+count_symbol+"\n����� �������� ��� ������� = "+csns+
		  		"\n������� ���� = "+
				  		count_tall+" \n������� �������� = "+count_small);
		  	
		  		   
		      };

		  });

	}

}
